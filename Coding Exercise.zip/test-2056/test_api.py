import pytest
import app as main
from datetime import date,datetime

@pytest.fixture
def client():
    main.app.config["TESTING"] = True
    client = main.app.test_client()
    with main.app.app_context():
        main.db.drop_all()
        main.db.create_all()
        weather_data = main.Weather_data_model(
            station="station_name",
            date=datetime.combine(date(1999,1,1),datetime.min.time()),
            maximum_temperature=1,
            minimum_temperature=1,
            precipitation=10,
        )
        main.db.session.add(weather_data)
        main.db.session.commit()

    yield client


def test_weather_reports(client):
    response = client.get("/api/weather/")
    assert response.status_code == 200
    assert response.json == [
        {
            "date": "Fri, 01 Jan 1999 00:00:00 GMT",
            "maximum_temperature": 1,
            "minimum_temperature": 1,
            "precipitation": 10,
            "station": "station_name",
        }
    ]
