from datetime import date, datetime
import click
from flask import Flask
from flask import jsonify
from flask import request
from flask_sqlalchemy import SQLAlchemy
from flask_swagger_ui import get_swaggerui_blueprint
try:
    from .ingest import (
        calculate_report,
        ingest_wx_data,
    )
except Exception:
    from ingest import (
        calculate_report,
        ingest_wx_data,
    )


app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///db.sqlite"


# flask swagger configs
SWAGGER_URL = '/swagger'
API_URL = '/static/swagger.json'
SWAGGERUI_BLUEPRINT = get_swaggerui_blueprint(
    SWAGGER_URL,
    API_URL,
    config={
        'app_name': "List API"
    }
)
app.register_blueprint(SWAGGERUI_BLUEPRINT, url_prefix=SWAGGER_URL)



db = SQLAlchemy(app)


class Weather_data_model(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    station = db.Column(db.String(15))
    date=db.Column(db.DateTime)
    maximum_temperature = db.Column(db.Integer)
    minimum_temperature = db.Column(db.Integer)
    precipitation = db.Column(db.Integer)

    @property
    def serialize(self):
        return {
            "station": self.station,
            "date": self.date,
            "maximum_temperature": self.maximum_temperature,
            "minimum_temperature": self.minimum_temperature,
            "precipitation": self.precipitation,
        }


class Report(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    station = db.Column(db.String(15))
    date = db.Column(db.DateTime)
    calculated_max_temperature = db.Column(db.Integer)
    calculated_minimum_temperature = db.Column(db.Integer)
    calculated_precipitation = db.Column(db.Integer)

    @property
    def serialize(self):
        return {
            "station": self.station,
            "date": self.date,
            "calculated_max_temperature": self.calculated_max_temperature,
            "calculated_minimum_temperature": self.calculated_minimum_temperature,
            "calculated_precipitation": self.calculated_precipitation,
        }


@click.command(name="prepare_project")
def prepare_project():
    with app.app_context():
        db.drop_all()
        db.create_all()
        ingest_wx_data()
        calculate_report()


@app.route("/api/weather/", methods=["GET"])
def weather_home():
    page = request.args.get("page", type=int)
    d = request.args.get("date")
    station = request.args.get("station")
    result = Weather_data_model.query
    if d:
        temp=d
        temp=list(map(int,temp.split('-')))
        d=date(temp[0],temp[1],temp[2])
        d=datetime.combine(d,datetime.min.time())
        result = result.filter(Weather_data_model.date == d)
    if station:
        result = result.filter(Weather_data_model.station == station)

    return jsonify([r.serialize for r in result.paginate(page=page, per_page=100)])




@app.route("/api/weather/stats/", methods=["GET"])
def stats():
    page = request.args.get("page", type=int)
    d = request.args.get("date")
    station = request.args.get("station")
    data = Report.query
    if d:
        temp=d
        temp=list(map(int,temp.split('-')))
        d=date(temp[0],temp[1],temp[2])
        d=datetime.combine(d,datetime.min.time())
        data = data.filter(Report.date == d)

    if station:
        data = data.filter(Report.station == station)

    return jsonify([r.serialize for r in data.paginate(page=page, per_page=100)])


if __name__ == "__main__":
    app.run(debug=True)

app.cli.add_command(prepare_project)
