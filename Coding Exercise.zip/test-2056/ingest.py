import os
import logging
from datetime import datetime,date

logging.basicConfig(filename="logs/record.log", level=logging.DEBUG)
logger = logging.getLogger(__name__)


def collect_wx_data():
    print("Collecting wx Data...")
    rows = []
    location = os.path.join(os.getcwd(), "wx_data")
    from app import Weather_data_model

    for file in os.listdir(location):
        if file.endswith(".txt"):
            print("reading file:", file)
            filepath = os.path.join(location, file)
            with open(filepath, "r") as f:
                for line in map(str.strip, f):
                    row = line.split("\t")
                    obj = Weather_data_model(
                        station=file[:-4],
                        date=date(int(row[0][0:4]),int(row[0][4:6]),int(row[0][6:])),
                        maximum_temperature=int(row[1]),
                        minimum_temperature=int(row[2]),
                        precipitation=int(row[3]),
                    )
                    rows.append(obj)
    print(f"File read complete: got {len(rows)} rows")
    return rows


def ingest_wx_data():
    from app import db

    start_time = datetime.now()

    rows = collect_wx_data()
    session = db.session
    print("**** Inserting Data To Database ****")
    session.bulk_save_objects(rows)
    session.commit()
    logger.info("**** Data Inserted ****")
    finish_time = datetime.now()
    logger.info(
        f"Data inserted in: {(finish_time - start_time).total_seconds()} secs \t Total rows affected : {len(rows)}"
    )
    print("Data Insertion Successful")


def calculate_report():
    from app import db

    query = """
            INSERT INTO report(station, date,  calculated_max_temperature, calculated_minimum_temperature, calculated_precipitation)
            SELECT station,date, avg(maximum_temperature),avg(minimum_temperature), sum(precipitation)
                from (
                    select * from weather_data_model
                    where maximum_temperature != -9999
                    and minimum_temperature != -9999
                    and precipitation != -9999
                ) group by station, substring(date, 1, 4)
            """
    session = db.session
    session.execute(query)
    session.commit()
    logger.info("**** Report Data Calculated and Inserted Into Table ****")
